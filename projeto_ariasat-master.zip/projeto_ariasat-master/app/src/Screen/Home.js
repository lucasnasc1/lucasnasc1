import React from "react";
import { useState } from "react";
import CookieConsent from 'react-cookie-consent';

          //Link components
import Banner from "../components/Banner";
import Header from "../components/Header";
import InfoHome from "../components/InfoHome";
import ServicosHome from "../components/ServicosHome";
import Footer from "../components/Footer";
import Politica from "./Politica";


export default () => {

  return(
    <div>
      <Header/>
      SetCookie(Politica, cookie_value)
        expires={7}
      
      <CookieConsent 
      
      debug={true}
      location="bottom"
      expires={7}
      style={{
        textAlign: "left",
        color: "#fff"
      }}
      buttonStyle={{color: "#000", background: "#ffff", fontSize: 14}}
      buttonText="Ok, entendi!"
      >  
      Esse site usa cookies. Veja nossa <a href="/politicas">Politica de privacidade</a>.
    </CookieConsent>
      <Banner/>
      <InfoHome/>
      <ServicosHome/>
      <Footer/>
    </div>
  )
}