import React from "react";
import {Route, Routes, BrowserRouter} from "react-router-dom";

import Contato from "./Screen/Contato";
import Geotab from "./Screen/Geotab";
import Home from "./Screen/Home";
import Lytx from "./Screen/Lytx";
import Preps from "./Screen/Preps";
import Telemetria from "./Screen/Telemetria";
import FormEnviado from "./Screen/FormEnviado";


import "./style/global.css";
import Politica from "./Screen/Politica";
 
export default () =>{
  return( 
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/Contato" element={<Contato/>}/>
        <Route path="/Geotab" element={<Geotab/>}/> 
        <Route path="/Lytx" element={<Lytx/> } />
        <Route path="/Preps" element={<Preps/>}/>
        <Route path="/Telemetria" element={<Telemetria/>} /> 
        <Route path="/FormularioEnviado" element={<FormEnviado/>}/>
        <Route path="/politicas" element={<Politica/>}/>
      </Routes>
    </BrowserRouter>
  );
}
