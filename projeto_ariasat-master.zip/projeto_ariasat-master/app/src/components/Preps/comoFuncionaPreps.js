import React from "react";
import "../../style/Preps/comoFuncionaPreps.css"


export default () => {
  return(
    <div>
      <div className="main-cont-preps">
        <div className="text-main-cont-preps">
          <h4>Como funciona</h4>
          <p>O barco manda informações a cada hora para um dos satélites globais através de um sistema de localização GPS. Esse satélite retorna as informações para o órgão marítimo responsável que por sua vez irá monitorar sua embarcação.
          <br />
          Havendo algum imprevisto poderá ser acionado o botão pânico que informa que a embarcação possui alguma anormalidade.</p>
        </div>
        <img src="https://geotab.ariasat.net.br/images/general/Preps.png" alt="" />
      </div>
    </div>
  );
}